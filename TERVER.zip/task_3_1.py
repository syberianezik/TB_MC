sigma_x = math.sqrt(x_xi)
sigma_y = math.sqrt(y_yi)
for i in range(rows):
xy += data.loc[i][1] * data.loc[i][2]

xy_m = xy / rows
m1 = data.iloc[:, 1].mean()
m2 = data.iloc[:, 2].mean()

r = (xy_m - m1 * m2) / (sigma_x * sigma_y) # weak dependence
c = xy_m - m1 * m2
print("r",r)
print(c)
gamma = 0.95

T = (r/math.sqrt(1-r**2))*(math.sqrt(rows-2))
print("T",T)
tss = sy

T_table = 1.96
#r - кореляция
#с - ковариация