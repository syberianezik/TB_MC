import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import scipy.stats as sps
from math import sqrt


def get_mean(data):  # выборочное среднее
    return data.mean()


def get_population_var(data, mean):  # выборочная дисперсия
    sample_var = 0
    for x in data:
        sample_var += (x - mean) ** 2
    return sample_var / len(data)


def get_sample_var(data, mean):  # выборочная несмещенная дисперсия
    sample_var = 0
    for x in data:
        sample_var += (x - mean) ** 2
    return sample_var / (len(data) - 1)


def get_min_ordinal_statistic(data):  # минимальная выборочная статистика
    return data.min()


def get_max_ordinal_statistic(data):  # максимальная выборочная статистика
    return data.max()


def get_median(data):  # медиана
    k = len(data) / 2
    var_series = data.sort_values()
    median = (var_series[k] + var_series[k+1]) / 2
    return median

"""def get_median(x):
    if len(x) % 2 == 0:
        median = x[int((len(x) + 1) / 2)]
    else:
        median = x[int(len(x) / 2)] + x[int((len(x) / 2) + 1)]/2
    return median"""


def show_empirical_distribution_function(data: pd.Series):  # показать график эмпирической функции распределения
    sns.ecdfplot(data=data)
    plt.show()


def show_hist(data: pd.Series):  # показать гистограмму
    sns.histplot(data)
    plt.show()


def show_kde(data: pd.Series):  # показать ядерную оценку функции плотности
    sns.kdeplot(data, bw_adjust=0.5)
    plt.show()


def dn(data, mean, var):
    sort_data = sorted(data)
    d_plus = 0
    for i, x in enumerate(sort_data):
        d_plus = max(d_plus, (i + 1) / len(sort_data) - sps.norm(loc=mean, scale=var).cdf(x))

    d_minus = 0
    for i, x in enumerate(sort_data):
        d_minus = max(d_minus, sps.norm(loc=mean, scale=var).cdf(x) - i / len(sort_data))

    return max(d_minus, d_plus)


def sk(data, mean, var):
    return (6 * len(data) * dn(data, mean, var) + 1) / (6 * sqrt(len(data)))


def is_normal_distribution(data, mean, var):  # показать, является ли нормальным распределением
    ssk = sk(data, mean, var)
    return ssk <= 1.0599


def main():
    data = pd.read_csv("iris.csv")
    data = data[data["name"] == "Iris-versicolor"]
    data = data["petal_length"]

    #k = len(data) / 2
    mean = get_mean(data)
    population_var = get_population_var(data, mean)
    sample_var = get_sample_var(data, mean)
    min_ord_statistic = get_min_ordinal_statistic(data)
    max_ord_statistic = get_max_ordinal_statistic(data)
    ord_range = max_ord_statistic - min_ord_statistic
    median = get_median(data)
    print("выборочное среднее =", mean)
    print("выборочная дисперсия =", population_var)
    print("выборочная несмещенная дисперсия =", sample_var)
    print("минимальная выборочная статистика =", min_ord_statistic)
    print("минимальная выборочная статистика =", max_ord_statistic)
    print("размах =", ord_range)
    print("медиана =", median)

    show_empirical_distribution_function(data)
    show_hist(data)
    show_kde(data)

    # для уровня значимости 0.01
    print("является ли нормальным распределением?", is_normal_distribution(data, mean, sqrt(population_var)))


if __name__ == "__main__":
    main()
