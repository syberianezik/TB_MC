from typing import Union, Any
import numpy as np
from numpy import ndarray
from pandas import Series, DataFrame
from pandas.core.arrays import ExtensionArray
from pandas.core.generic import NDFrame
from scipy import stats as sps
import pandas as pd
import sklearn
from sklearn.model_selection import train_test_split
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB

data = pd.read_csv("https://raw.githubusercontent.com/syberianezik/TB_MC/main/iris.csv")

data_class1 = data[data["name"] == "Iris-versicolor"]
data_class1 = data_class1["petal_width"]
data_class2 = data[data["name"] == "Iris-virginica"]
data_class2 = data_class2["petal_width"]

data_class1 = data_class1.to_numpy()
data_class2 = data_class2.to_numpy()

train1, test1 = train_test_split(data_class1, test_size=0.2)  #
train2, test2 = train_test_split(data_class2, test_size=0.2)  #
test = np.concatenate([test1, test2])

u1 = train1.sum() / train1.size
u2 = train2.sum() / train2.size

o1 = ((train1 - u1) ** 2).sum() / train1.size
o2 = ((train2 - u2) ** 2).sum() / train2.size

for i in test:
    if sps.norm(loc=u1, scale=o1).pdf(i) > sps.norm(loc=u2, scale=o2).pdf(i):  # байсо
        print("Iris-versicolor")
    else:
        print("Iris-virginica")

predictions = {"TP": 0, "TN": 0}
for i in test1:  # посчитаем количество правильных предсказаний Iris-versicolor
    if sps.norm(loc=mean1, scale=sqrt(var1)).pdf(i) > sps.norm(loc=mean2, scale=sqrt(var2)).pdf(i):
        predictions["TP"] += 1

for i in test2:  # посчитаем количество правильных предсказаний Iris-setosa
    if sps.norm(loc=mean1, scale=sqrt(var1)).pdf(i) < sps.norm(loc=mean2, scale=sqrt(var2)).pdf(i):
        predictions["TN"] += 1

print(predictions["TP"], predictions["TN"])

#  посчитаем точность классификатора Байеса
accuracy = (predictions["TP"] + predictions["TN"]) / (len(test1) + len(test2))
print("точность классификатора =", accuracy, f"({accuracy * 100}%)")
