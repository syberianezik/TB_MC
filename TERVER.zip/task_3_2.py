import math
import numpy as np


def calculate_sums(data):
    strings = np.sum(data, axis=1)
    columns = np.sum(data, axis=0)
    general_sum = np.sum(strings)
    dof = (int(len(strings)) - 1) * (int(len(columns)) - 1)
    return columns, strings, general_sum, dof


def calculate_statistics_of_criterion(data, columns, strings, n):
    dims = np.shape(data)
    sum = 0
    for i in range(dims[0]):
        for j in range(dims[1]):
            sum += float(data[i][j] * data[i][j]) / (columns[i] * strings[j])
            sum = n * (sum - 1)
    return sum


def create_partition(data, partitions):
    dims = np.shape(data)
    table = np.zeros((partitions, partitions))

    for i in range(dims[0]):
        min_ = np.min(data[i])
    for j in range(dims[1]):
        data[i][j] -= min_

    delta_arr = []

    for i in range(dims[0]):
        delta_arr.append(float(np.max(data[i])) / partitions)

    for i in range(dims[0] - 1):
        for j in range(dims[1]):
            ii = min(math.floor(data[i][j] / delta_arr[i]), partitions - 1)
            jj = min(math.floor(data[i+1][j] / delta_arr[i+1]), partitions - 1)
            table[ii][jj] += 1

    return table


def check_independence(data, alpha=0.01, partitions=5, chi_square_table=None):
    # data = np.array([[170, 179, 187, 189, 193, 199, 200, 207, 215, 216, 220, 225],
    # [152, 159, 162, 165, 170, 172, 177, 179, 184, 186, 190, 191]])
    data = create_partition(data, partitions)
    columns, strings, n, dof = calculate_sums(data)
    res = calculate_statistics_of_criterion(data, columns, strings, n)
    critical_val = float(chi_square_table.iloc[dof - 1]['a' + str(alpha)].replace(',', '.'))

    print("result is", res)
    print("function is", critical_val)
    if res > critical_val:
        print("the values are NOT independent")
    else:
        print("the values are independent")
    return n